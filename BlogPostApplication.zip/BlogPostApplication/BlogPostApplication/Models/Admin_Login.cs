﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BlogPostApplication.Models
{
    public class Admin_Login
    {
        [Key]
        [Required]
        public int Id { get; set; }
        [Required(ErrorMessage = "username is required")]
        public string username { get; set; }

        [Required(ErrorMessage = "password is required")]
        public string Password { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BlogPostApplication.Models
{
    public class BlogPost
    {
        [Key]
        public int PostId { get; set; }
        [Required(ErrorMessage = "Post title is required")]
        [MaxLength(100)]
        [MinLength(3)]
        public string PostTitle { get; set; }
        [Required(ErrorMessage = "Post abstract is required")]
        [MaxLength(100)]
        [MinLength(3)]
        public string PostAbstract { get; set; }
        [Required(ErrorMessage = "Post abstarction is required")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Post category is required")]
        public Pcategory PostCategory { get; set; }
        [Required(ErrorMessage = "Post sub category is required")]
        public PSubCategory PostSubCategory { get; set; }
        [Required]
        [DataType(DataType.PhoneNumber)]
        public long Phone { get; set; }

        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Date is required")]
        [DataType(DataType.Date)]
        public DateTime CreatedOn { get; set; }
    }

    public enum Pcategory
    {
        Educational = 1,
        Music = 2,
        Food = 3,
        Travel = 4,
        Movies=1
    }
    public enum PSubCategory
    {
        Classical = 1,
        IndianCuisine = 2,
        Fiction = 3,
        Horror = 4

    }
}

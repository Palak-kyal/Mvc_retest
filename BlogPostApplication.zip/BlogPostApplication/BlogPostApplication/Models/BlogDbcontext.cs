﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace BlogPostApplication.Models
{
    public class BlogDbcontext : DbContext
    {
        
          

            public DbSet<Admin_Login> admin_login { get; set; }
            public DbSet<Register> register { get; set; }
            public DbSet<BlogPost> blogpost { get; set; }
       
    }
}